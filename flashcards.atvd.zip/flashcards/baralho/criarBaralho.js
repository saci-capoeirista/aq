let {baralho} = require("../data")
function criarBaralho(baralhos){
    baralhos.id = baralho.length + 1;
    baralho.push(baralhos)
}
module.exports = criarBaralho