let  baralho = [
    {id: 1, nomebaralho: "verdades"},
]
let flashcard = [
    {id: 1, pergunta:"neymar goat?", resposta: "sim", idBaralho: 1 }
]
module.exports = {baralho, flashcard}

